const menuBar = document.querySelector(".fa-bars");
const menu = document.querySelector("#menu");

menuBar.addEventListener("click", () => {
  menu.classList.toggle("show");
});
